﻿安装：
  把本压缩包放入 GP-Next 的 packs 目录：
  %APPDATA%\com.pvzge.game\gp-next\packs\
  然后在 GP-Next 面板中启用/保存并重载游戏。

卸载：
  在 GP-Next 中禁用该 Mod，或删除 packs 中对应 zip。
