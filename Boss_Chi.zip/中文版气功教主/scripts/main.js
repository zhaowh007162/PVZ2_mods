/* ============================================================
 * 气功教主·金钟罩 — GP-Next runtime mod v1.4.6
 * 1. 取消了多教主充能条的横向错位，固定在中下方
 * 2. 彻底解决对象池复用导致的时间线继承 bug，每个教主独立
 * ============================================================ */
const CONFIG = {
  DEBUG_CHERRY_CLEAR_SHIELD: true,

  LOG_PATH: 'DESKTOP/dsh-shield-mod.log',
  LOG_ALL_OPS: false,
  LOG_OP_THROTTLE_MS: 100,
  LOG_STARTUP: false,

  ICE_SHIELD_HP: 15000,
  FIRE_SHIELD_HP: 15000,

  DAMAGE_CAP_PCT: 0.01,
  ICE_HIT_DAMAGE: 50,
  ICE_HIT_COOLDOWN_MS: 500,
  FIRE_MIN_DAMAGE: 50,
  FIRE_DAMAGE_MULT: 2,

  RESPAWN_CD: 30,
  MIN_SPAWN_GUARD_MS: 2500,
  BREAK_DELAY: 0.6,

  HEAL_PER_SEC: 10,

  LAYER: 65536,
  BAR_W: 210,
  BAR_H: 7,
  BAR_X: -115,
  BAR_Y: -4,
  ICON_X: -134,
  ICON_R: 13,

  FIRST_SHIELD_DELAY_MS: 8500, // 进场延迟开盾时间

  // ---------- 充能条 ----------
  CHARGE_BAR_W_BOTTOM: 100,
  CHARGE_BAR_H: 12,
  CHARGE_BOTTOM_X: -70,
  CHARGE_BOTTOM_Y: -400,
  CHARGE_BOTTOM_MARGIN: 31,
  CHARGE_USE_CAMERA: true,
};

let CC = null;
let SND = null;
let ticker = null;
let proto = null;
let patched = false;
let cherryPatched = false;
let __logPath = null;
let __lastTick = 0;
let __lastCherryScan = 0;

const ATLAS_COLOR_CACHE = new WeakMap();
const SHIELD_FRAME_NAMES = ['shield_light', 'shield_side', 'shield_lit', 'shield_crack1', 'shield_crack2'];

const SKIP_METHODS = new Set([
  'update', 'lateUpdate', 'onLoad', 'start', 'onEnable', 'onDisable',
  'getComponent', 'getComponents', 'getChildByName', 'addComponent', 'destroy',
  'setPosition', 'setScale', 'setRotation', 'getPosition', 'getScale',
  'playAnimation', 'stopAnimation', 'getAnimationState',
  'isAlive', 'isValid',
  'specialZombossUpdate', 'specialZombossUpdateForce',
]);

const SKIP_SNAPSHOT = new Set([
  'node', 'parent', 'children', 'components', 'scene',
  'dshShieldBar', 'dshShieldAura', 'dshShieldFx', 'dshHealFx',
  'dshShieldCamNode', 'dshShieldBarStyleApply',
  'dshShieldChargeBar', 'dshShieldChargeBarNode',
  'shieldDBs', 'currentMechStages', '_dshStateSnapshot', '_dshMethodTimes',
]);

function resolveLogPath() {
  const p = CONFIG.LOG_PATH;
  if (!p) return null;
  if (p.indexOf('DESKTOP/') === 0) {
    try {
      const os = window.require('os');
      const home = os.homedir();
      const tail = p.substring('DESKTOP/'.length);
      return [
        home + '\\Desktop\\' + tail,
        home + '\\OneDrive\\Desktop\\' + tail,
        home + '\\' + tail
      ];
    } catch (e) { return null; }
  }
  return [p];
}

function LOG(m) {
  try { console.log('[DSH shield] ' + m); } catch (e) { }
  try {
    if (!window.require) return;
    const fs = window.require('fs');
    if (!__logPath) {
      const candidates = resolveLogPath();
      if (!candidates || !candidates.length) { __logPath = '__none__'; return; }
      for (const p of candidates) {
        try {
          fs.appendFileSync(p, '\n--- dsh shield mod session ---\n');
          __logPath = p;
          try { console.log('[DSH shield] log file: ' + p); } catch (e) { }
          break;
        } catch (e) { }
      }
      if (!__logPath) { __logPath = '__none__'; return; }
    }
    if (__logPath !== '__none__') {
      fs.appendFileSync(__logPath, Date.now() + ' ' + m + '\n');
    }
  } catch (e) { }
}
function LOGERR(tag, e) {
  try { console.error('[DSH shield] ' + tag, e); } catch (x) { }
  try { LOG('[ERROR] ' + tag + ' ' + String(e && e.stack || e)); } catch (x) { }
}
function STARTUP_LOG(m) {
  if (!CONFIG.LOG_STARTUP) return;
  LOG(m);
}

/* ---------- 樱桃炸弹钩子 ---------- */
function hookCherryClass(C) {
  if (!C || !C.prototype || typeof C.prototype.explode !== 'function' || C.prototype.__dshCherryPatched) return;
  const orig = C.prototype.explode;
  C.prototype.explode = function () {
    try { window.__dshCherryExplosion = { t: Date.now() }; } catch (e) { }
    if (CONFIG.DEBUG_CHERRY_CLEAR_SHIELD) LOG('[CHERRY] explode triggered');
    return orig.apply(this, arguments);
  };
  C.prototype.__dshCherryPatched = true;
  cherryPatched = true;
  STARTUP_LOG('[SETUP] patched cherry: ' + (C.name || ''));
}

function patchCherryBomb(force) {
  if (!CONFIG.DEBUG_CHERRY_CLEAR_SHIELD && !force) return;
  try {
    const now = Date.now();
    if (!force && now - __lastCherryScan < 500) return;
    __lastCherryScan = now;

    ['CherryBombPlant', 'CherryBombMGPPlant', 'CherryBombMGP', 'CherryBombPlantMGP', 'CherryBomb'].forEach(function (n) {
      try { hookCherryClass(CC.js && CC.js.getClassByName && CC.js.getClassByName(n)); } catch (e) { }
    });

    const scene = CC.director && CC.director.getScene();
    if (!scene) return;
    const walk = function (n, d) {
      if (!n || d > 80) return;
      for (const c of (n.components || [])) {
        try {
          if (c && typeof c.explode === 'function') {
            const cn = (CC.js && CC.js.getClassName && CC.js.getClassName(c)) || (c.constructor && c.constructor.name) || '';
            if (/Cherry/i.test(cn)) hookCherryClass(Object.getPrototypeOf(c));
          }
        } catch (e) { }
      }
      for (const ch of (n.children || [])) walk(ch, d + 1);
    };
    walk(scene, 0);
  } catch (e) { LOGERR('patch-cherry', e); }
}

/* ---------- 方法包装 ---------- */
function wrapBossMethods(proto) {
  const seen = new Set();
  const wrapped = [];
  let p = proto;
  let depth = 0;
  while (p && p !== Object.prototype && depth < 8) {
    const names = Object.getOwnPropertyNames(p);
    for (const key of names) {
      if (seen.has(key)) continue;
      seen.add(key);
      if (key === 'constructor') continue;
      if (SKIP_METHODS.has(key)) continue;
      if (key.indexOf('__dsh') === 0) continue;
      if (key.indexOf('dsh') === 0) continue;
      let desc;
      try { desc = Object.getOwnPropertyDescriptor(p, key); } catch (e) { continue; }
      if (!desc || typeof desc.value !== 'function') continue;
      if (desc.value.__dshOpWrapped) continue;
      const orig = desc.value;
      const wrap = function () {
        try {
          if (CONFIG.LOG_ALL_OPS) {
            const now = Date.now();
            if (!this._dshMethodTimes) this._dshMethodTimes = {};
            const last = this._dshMethodTimes[key] || 0;
            if (now - last >= CONFIG.LOG_OP_THROTTLE_MS) {
              this._dshMethodTimes[key] = now;
              const n = arguments.length;
              let extra = '';
              if (n > 0) {
                try {
                  const a0 = arguments[0];
                  if (typeof a0 === 'number' || typeof a0 === 'string' || typeof a0 === 'boolean') extra = ' a0=' + a0;
                  else if (a0 && typeof a0 === 'object' && a0.damage != null) extra = ' dmg=' + a0.damage + ' type=' + a0.damageType;
                } catch (e) { }
              }
              LOG('[OP] ' + key + '(' + n + ')' + extra + ' stage=' + this.currentStage + ' hp=' + this.health);
            }
          }
        } catch (e) { }
        return orig.apply(this, arguments);
      };
      wrap.__dshOpWrapped = true;
      wrap.__dshOrig = orig;
      try {
        Object.defineProperty(p, key, {
          configurable: true,
          enumerable: desc.enumerable,
          writable: true,
          value: wrap
        });
        wrapped.push(key);
      } catch (e) { }
    }
    p = Object.getPrototypeOf(p);
    depth++;
  }
  if (wrapped.length) STARTUP_LOG('[SETUP] wrapped methods: ' + wrapped.join(','));
}

/* ---------- 状态快照 ---------- */
function dshDumpState(b, tag) {
  try {
    if (!b._dshStateSnapshot) b._dshStateSnapshot = {};
    const snap = b._dshStateSnapshot;
    const cur = {};
    for (const key in b) {
      if (SKIP_SNAPSHOT.has(key)) continue;
      if (key.indexOf('__dsh') === 0 || key.indexOf('_dsh') === 0) continue;
      let v;
      try { v = b[key]; } catch (e) { continue; }
      if (typeof v === 'function') continue;
      if (v === null) cur[key] = 'null';
      else if (v === undefined) cur[key] = 'undef';
      else if (typeof v === 'number' || typeof v === 'string' || typeof v === 'boolean') cur[key] = v;
      else if (Array.isArray(v)) cur[key] = 'arr(' + v.length + ')';
      else continue;
    }
    const changes = [];
    for (const k in cur) {
      if (!(k in snap) || snap[k] !== cur[k]) {
        changes.push(k + '=' + (snap[k] === undefined ? '?' : snap[k]) + '->' + cur[k]);
      }
    }
    if (changes.length && CONFIG.LOG_ALL_OPS) {
      LOG('[STATE ' + tag + '] ' + changes.join(' | '));
    }
    b._dshStateSnapshot = cur;
  } catch (e) { }
}

/* ---------- 原 mod 逻辑 ---------- */
function recolorShieldAtlas(CC, db, el) {
  try {
    if (!db || !db._dragonAtlasAsset) return;
    const atlas = db._dragonAtlasAsset;
    const tex = atlas._texture;
    if (!tex || !tex.image) return;
    let cache = ATLAS_COLOR_CACHE.get(tex);
    if (!cache) {
      const img = tex.image._nativeAsset || tex.image._image;
      if (!img) return;
      const base = document.createElement('canvas');
      base.width = tex.width; base.height = tex.height;
      const bctx = base.getContext('2d');
      bctx.drawImage(img, 0, 0);
      cache = { base: base, last: null };
      ATLAS_COLOR_CACHE.set(tex, cache);
    }
    const canvas = document.createElement('canvas');
    canvas.width = tex.width; canvas.height = tex.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(cache.base, 0, 0);
    const textures = atlas._textureAtlasData && atlas._textureAtlasData.textures;
    if (!textures) return;
    const blue = el === 'fire';
    for (const name of SHIELD_FRAME_NAMES) {
      const data = textures[name];
      const r = data && data.region;
      if (!r) continue;
      const imgData = ctx.getImageData(r.x, r.y, r.width, r.height);
      const p = imgData.data;
      for (let i = 0; i < p.length; i += 4) {
        if (p[i + 3] === 0) continue;
        const lum = (0.299 * p[i] + 0.587 * p[i + 1] + 0.114 * p[i + 2]) / 255;
        const k = 0.30 + 0.70 * lum;
        if (blue) {
          p[i] = Math.min(255, 25 + 75 * k);
          p[i + 1] = Math.min(255, 140 + 100 * k);
          p[i + 2] = Math.min(255, 205 + 50 * k);
        } else {
          p[i] = 255;
          p[i + 1] = Math.min(255, 62 + 92 * k);
          p[i + 2] = Math.min(255, 8 * k);
          p[i + 3] = Math.min(255, Math.round(p[i + 3] * 1.25 + 20));
        }
      }
      ctx.putImageData(imgData, r.x, r.y);
    }
    const full = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    tex.uploadData(full, 0, 0);
    tex.__dshShieldColor = el;
    cache.last = el;
    try { db.setTextureDirty(); } catch (e) { }
    try { db.markForUpdateRenderData && db.markForUpdateRenderData(true); } catch (e) { }
  } catch (e) {
    try { LOG('[ERROR] recolorShieldAtlas ' + String(e && e.stack || e)); } catch (_) { }
  }
}

function hasActiveOriginalShieldNode(b) {
  return (b.shieldDBs || []).some(function (db) {
    try { return db && db.node && db.node.active; } catch (e) { return false; }
  });
}

function install(l, cc) {
  if (!l || l.__dshShieldPatched) return;

  if (cc && cc.Node && !cc.Node.prototype.setLayer) { cc.Node.prototype.setLayer = function (l2) { this.layer = l2; return this; }; }
  var origDealDamage = l.dealDamage;
  var origShield = l.shield;
  var origKillShield = l.killShield;
  var origUpdate = l.specialZombossUpdate;
  var origUpdateForce = l.specialZombossUpdateForce;
  var origEnable = l.specialZombossMechOnEnable;
  var origDie = l.specialZombossDieForce;
  var origDisable = l.specialZombossOnDisable;
  var origSetChill = l.setChill;
  var origSetFreeze = l.setFreeze;
  var LAYER = CONFIG.LAYER;
  var BAR_W = CONFIG.BAR_W;
  var BAR_H = CONFIG.BAR_H;
  var BAR_X = CONFIG.BAR_X;
  var BAR_Y = CONFIG.BAR_Y;
  var ICON_X = CONFIG.ICON_X;
  var ICON_R = CONFIG.ICON_R;
  var RESPAWN_CD = CONFIG.RESPAWN_CD;

  function C(r, g, b, a) { return new cc.Color(r, g, b, a == null ? 255 : a); }
  function clamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
  function style(el) {
    if (el === 'fire') return {
      name: '火', glyph: 'fire',
      tint: [92, 182, 255],
      fill: [255, 146, 46], fill2: [255, 204, 92],
      badge: [172, 40, 23], edge: [255, 218, 130]
    };
    return {
      name: '冰', glyph: 'ice',
      tint: [255, 176, 86],
      fill: [74, 190, 255], fill2: [184, 240, 255],
      badge: [24, 112, 174], edge: [172, 236, 255]
    };
  }
  function err(e) { try { window.__dshShieldErr = String(e && e.stack || e); } catch (_) { } try { console.warn('[DSH shield]', e); } catch (_) { } }

  function forceCloseOriginalShield(b) {
    try {
      b.shieldCD = Infinity;
      (b.shieldDBs || []).forEach(function (db) {
        try { if (db && db.node) db.node.active = false; } catch (_) { }
      });
    } catch (e) { LOGERR('forceCloseOriginalShield', e); }
  }

  l.dshShieldEnsureCamera = function () {
    try {
      if (this.dshShieldCamNode && this.dshShieldCamNode.isValid) return this.dshShieldCamNode;
      var scene = cc.director && cc.director.getScene && cc.director.getScene();
      if (!scene || !this.node) return null;
      var layer = this.node.layer || 512;
      var src = null, fallback = null, maxPri = -1e9, srcPri = -1e9;
      var scan = function (n) {
        if (!n) return;
        var cam = n.getComponent && n.getComponent('cc.Camera');
        if (cam) {
          if (cam.priority > maxPri) { maxPri = cam.priority; fallback = cam; }
          if ((cam.visibility & layer) && cam.priority >= srcPri) { srcPri = cam.priority; src = cam; }
        }
        var ch = n.children || [];
        for (var i = 0; i < ch.length; i++) scan(ch[i]);
      };
      scan(scene);
      var sc = src || fallback;
      if (!sc || !sc.node) return null;
      var cn = cc.instantiate(sc.node);
      cn.parent = sc.node.parent;
      try {
        cn.setWorldPosition(sc.node.worldPosition.x, sc.node.worldPosition.y, sc.node.worldPosition.z);
        cn.setWorldRotation(sc.node.worldRotation);
        cn.setWorldScale(sc.node.worldScale);
      } catch (_) { }
      cn.active = true;
      cn.name = 'DshShieldBarCamera';
      var cam2 = cn.getComponent('cc.Camera');
      if (cam2) {
        cam2.visibility = LAYER;
        cam2.priority = maxPri + 20;
        cam2.clearFlags = 6;
        cam2.targetTexture = null;
        cam2.enabled = true;
      }
      this.dshShieldCamNode = cn;
      return cn;
    } catch (e) { err(e); return null; }
  };

  /* ================================================================
   * 充能条
   * ================================================================ */
  l.dshChargeBarBuild = function () {
    try {
      if (this.dshShieldChargeBar && this.dshShieldChargeBar.isValid) {
        this.dshShieldChargeBar.active = true;
        return this.dshShieldChargeBar;
      }
      if (!cc || !cc.Node) return null;
      this.dshShieldEnsureCamera();
      var root = new cc.Node('DshShieldChargeBar');
      root.parent = this.node;
      root.layer = LAYER;

      var bg = new cc.Node('bg');
      bg.parent = root; bg.layer = LAYER;
      var bgG = bg.addComponent(cc.Graphics);

      var fill = new cc.Node('fill');
      fill.parent = root; fill.layer = LAYER;
      var fillG = fill.addComponent(cc.Graphics);

      root.dshBg = bgG;
      root.dshFill = fillG;
      root.dshFillNode = fill;
      root.setLayerWithAllChildren(LAYER);

      this.dshShieldChargeBar = root;
      return root;
    } catch (e) { err(e); return null; }
  };

  l.dshChargeBarDraw = function (width, ratio, mode) {
    try {
      var root = this.dshShieldChargeBar;
      if (!root || !root.isValid) return;
      var bgG = root.dshBg;
      var fillG = root.dshFill;
      if (!bgG || !fillG) return;

      var H = CONFIG.CHARGE_BAR_H;
      var w = width;

      bgG.clear();
      bgG.fillColor = C(20, 15, 25, 220);
      bgG.roundRect(-w / 2 - 1, -H / 2 - 3, w + 2, H + 6, 3);
      bgG.fill();
      bgG.fillColor = C(8, 5, 10, 245);
      bgG.roundRect(-w / 2 + 1, -H / 2 - 1, w - 2, H + 2, 2);
      bgG.fill();

      fillG.clear();
      var innerW = w - 4;
      var fillW = Math.max(0, innerW * clamp01(ratio));
      if (fillW > 0.3) {
        var col = [0, 0, 0];
        if (ratio < 0.5) {
          // 绿到黄
          col[0] = Math.round(50 + ratio * 2 * 205);
          col[1] = 255;
          col[2] = 50;
        } else {
          // 黄到红
          col[0] = 255;
          col[1] = Math.round(255 - (ratio - 0.5) * 2 * 205);
          col[2] = 50;
        }
        fillG.fillColor = C(col[0], col[1], col[2], 255);
        fillG.roundRect(-w / 2 + 2, -H / 2, fillW, H, Math.min(3, fillW / 2));
        fillG.fill();
        fillG.fillColor = C(255, 255, 255, 80);
        fillG.roundRect(-w / 2 + 2, -H / 2 + 1, fillW, 2, 1);
        fillG.fill();
      }
    } catch (e) { err(e); }
  };

  l.dshChargeBarTick = function (dt) {
    try {
      if (this.health <= 0) {
        if (this.dshShieldChargeBar && this.dshShieldChargeBar.isValid) {
          this.dshShieldChargeBar.active = false;
        }
        return;
      }

      var root = this.dshShieldChargeBar;
      if (!root || !root.isValid) {
        root = this.dshChargeBarBuild();
        if (!root) return;
      }

      if (this.dshShieldActive) {
        root.active = false;
        return;
      }

      var remain = this.dshShieldCooldown || 0;
      if (remain > 0) {
        root.active = true;
        root.layer = LAYER;
        if (root.setLayerWithAllChildren) root.setLayerWithAllChildren(LAYER);

        var total = Math.max(1, CONFIG.RESPAWN_CD);
        var ratio = 1 - clamp01(remain / total);

        var bx = CONFIG.CHARGE_BOTTOM_X;
        var by = CONFIG.CHARGE_BOTTOM_Y;
        if (CONFIG.CHARGE_USE_CAMERA) {
          var camNode = this.dshShieldCamNode;
          var cam = camNode && camNode.isValid && camNode.getComponent('cc.Camera');
          if (cam && cam.orthoHeight) {
            var wp = camNode.worldPosition;
            var sc = Math.abs(camNode.worldScale.y) || 1;
            var halfH = cam.orthoHeight * sc;
            bx = wp.x + CONFIG.CHARGE_BOTTOM_X;
            by = wp.y - halfH + CONFIG.CHARGE_BOTTOM_MARGIN;
          }
        }

        var ws = Math.abs(this.node.worldScale.x) || 1;
        var parentScaleY2 = Math.abs(this.node.worldScale.y) || 1;
        root.setScale(1 / ws, 1 / parentScaleY2, 1);
        try { root.setWorldPosition(bx, by, 0); } catch (e2) { root.setPosition(bx, by, 0); }
        this.dshChargeBarDraw(CONFIG.CHARGE_BAR_W_BOTTOM, ratio, 'charging');
        return;
      }

      root.active = false;
    } catch (e) { err(e); }
  };

  l.dshChargeBarDestroy = function () {
    try { if (this.dshShieldChargeBar && this.dshShieldChargeBar.isValid) this.dshShieldChargeBar.destroy(); } catch (_) { }
    this.dshShieldChargeBar = null;
  };

  /* ================================================================
   * 韧性条
   * ================================================================ */
  function drawBadge(ig, el) {
    var s = style(el);
    ig.clear();
    ig.fillColor = C(18, 8, 8, 245);
    ig.roundRect(-ICON_R - 2, -ICON_R - 2, (ICON_R + 2) * 2, (ICON_R + 2) * 2, 6); ig.fill();
    ig.fillColor = C(s.badge[0], s.badge[1], s.badge[2], 255);
    ig.roundRect(-ICON_R, -ICON_R, ICON_R * 2, ICON_R * 2, 5); ig.fill();
    ig.strokeColor = C(s.edge[0], s.edge[1], s.edge[2], 255);
    ig.lineWidth = 1.2; ig.roundRect(-ICON_R + 1, -ICON_R + 1, ICON_R * 2 - 2, ICON_R * 2 - 2, 4); ig.stroke();
    ig.strokeColor = C(255, 255, 255, 255);
    ig.fillColor = C(255, 255, 255, 255);
    if (s.glyph === 'ice') {
      ig.lineWidth = 1.7;
      for (var i = 0; i < 6; i++) {
        var a = i * Math.PI / 3;
        var ca = Math.cos(a), sa = Math.sin(a);
        ig.moveTo(0, 0); ig.lineTo(ca * 8.6, sa * 8.6);
        var bx = ca * 5.1, by = sa * 5.1;
        var ba = a + 0.62;
        ig.moveTo(bx, by); ig.lineTo(bx + Math.cos(ba) * 3.2, by + Math.sin(ba) * 3.2);
        ba = a - 0.62;
        ig.moveTo(bx, by); ig.lineTo(bx + Math.cos(ba) * 3.2, by + Math.sin(ba) * 3.2);
      }
      ig.stroke();
      ig.circle(0, 0, 1.6); ig.fill();
    } else {
      ig.moveTo(0, 9.4);
      ig.bezierCurveTo(7.8, 5.8, 9.4, -0.6, 2.0, -9.0);
      ig.bezierCurveTo(2.8, -2.4, -1.8, -1.0, -3.4, 2.2);
      ig.bezierCurveTo(-7.8, -1.6, -8.0, 5.0, 0, 9.4);
      ig.fill();
      ig.fillColor = C(s.badge[0], s.badge[1], s.badge[2], 255);
      ig.moveTo(0, 6.2);
      ig.bezierCurveTo(3.8, 3.7, 4.2, 0.4, 1.3, -3.0);
      ig.bezierCurveTo(1.0, 0.8, -1.0, 1.4, -1.6, 3.2);
      ig.bezierCurveTo(-3.6, 1.8, -3.4, 4.0, 0, 6.2);
      ig.fill();
    }
  }

  l.dshShieldBarBuild = function () {
    var root = null;
    try {
      if (this.dshShieldBar && this.dshShieldBar.isValid) { this.dshShieldBar.active = true; return this.dshShieldBar; }
      if (!cc || !cc.Node) return null;
      this.dshShieldEnsureCamera();
      root = new cc.Node('DshShieldToughnessBar');
      root.parent = this.node;
      root.setPosition((this.dshShieldBarX == null ? 0 : this.dshShieldBarX) / (Math.abs(this.node.worldScale.x) || 1), (this.dshShieldBarY == null ? -10 : this.dshShieldBarY) / (Math.abs(this.node.worldScale.x) || 1), 0);
      root.layer = LAYER;

      var frame = new cc.Node('frame'); frame.parent = root; frame.layer = LAYER;
      var fg = frame.addComponent(cc.Graphics);
      fg.fillColor = C(250, 208, 84, 255);
      fg.roundRect(BAR_X - 1, BAR_Y - 4, BAR_W + 2, BAR_H + 8, 4); fg.fill();
      fg.fillColor = C(39, 10, 14, 245);
      fg.roundRect(BAR_X + 1, BAR_Y - 2, BAR_W - 2, BAR_H + 4, 3); fg.fill();

      var fillN = new cc.Node('fill'); fillN.parent = root; fillN.layer = LAYER; fillN.setPosition(BAR_X + 2, BAR_Y, 0);
      var fillG = fillN.addComponent(cc.Graphics);

      var iconN = new cc.Node('elementBadge'); iconN.parent = root; iconN.layer = LAYER;
      iconN.setPosition(ICON_X, 0, 0);
      var iconG = iconN.addComponent(cc.Graphics);

      root.dshFillG = fillG;
      root.dshIconG = iconG;
      root.dshStyleName = '';
      root.setLayerWithAllChildren(LAYER);
      this.dshShieldBar = root;
      this.dshShieldBarStyleApply();
      this.dshShieldBarUpdate();
      return root;
    } catch (e) { try { if (root && root.isValid) root.destroy(); } catch (_) { } err(e); this.dshShieldBar = null; return null; }
  };

  l.dshShieldBarStyleApply = function () {
    try {
      var bar = this.dshShieldBar;
      if (!bar || !bar.isValid) return;
      var s = style(this.dshShieldElement);
      if (bar.dshStyleName === s.name) return;
      bar.dshStyleName = s.name;
      if (bar.dshIconG) drawBadge(bar.dshIconG, this.dshShieldElement);
      this.dshShieldBarUpdate();
      this.dshShieldAuraBuild();
    } catch (e) { err(e); }
  };

  l.dshShieldBarUpdate = function () {
    try {
      if (!this.dshShieldActive) return;
      var bar = this.dshShieldBar;
      if (!bar || !bar.isValid) { bar = this.dshShieldBarBuild(); if (!bar) return; }
      if (!bar.active) bar.active = true;
      var s = style(this.dshShieldElement);
      if (bar.dshStyleName !== s.name) this.dshShieldBarStyleApply();
      if (bar.setLayerWithAllChildren) bar.setLayerWithAllChildren(LAYER);
      var ws = Math.abs(this.node.worldScale.x) || 1;
      var sign = (this.node.scale.x < 0) ? -1 : 1;
      var inv = 1 / ws;
      var pulse = 1;
      if (this.dshShieldBarPulseT > 0) pulse = 1 + 0.05 * Math.min(1, this.dshShieldBarPulseT / 0.18);
      bar.setScale(sign * inv * pulse, inv * pulse, 1);
      bar.setPosition((this.dshShieldBarX == null ? 0 : this.dshShieldBarX) / ws, (this.dshShieldBarY == null ? -10 : this.dshShieldBarY) / ws, 0);
      var mx = this.dshShieldMax || 1;
      var hp = Math.max(0, Math.min(mx, this.dshShieldHP || 0));
      var ratio = clamp01(hp / mx);
      var w = Math.max(0, (BAR_W - 4) * ratio);
      var g = bar.dshFillG;
      if (g) {
        g.clear();
        if (w > 0.4) {
          g.fillColor = C(s.fill[0], s.fill[1], s.fill[2], 255);
          g.roundRect(0, 0, w, BAR_H, Math.min(3.5, w / 2)); g.fill();
          g.fillColor = C(s.fill2[0], s.fill2[1], s.fill2[2], 215);
          g.roundRect(0, BAR_H - 2.2, Math.max(0, w), 1.6, 0.8); g.fill();
        }
        if (this.dshShieldBarPulseT > 0 && w > 0.5) {
          g.fillColor = C(255, 255, 255, 125);
          g.roundRect(0, 0, w, BAR_H, Math.min(3.5, w / 2)); g.fill();
        }
      }
    } catch (e) { err(e); }
  };

  l.dshShieldBarDestroy = function () {
    try { if (this.dshShieldBar && this.dshShieldBar.isValid) this.dshShieldBar.destroy(); } catch (_) { }
    this.dshShieldBar = null;
  };

  l.dshShieldApplyTint = function (flash) {
    try { if (!flash) recolorShieldAtlas(cc, this.shieldDBs && this.shieldDBs[0], this.dshShieldElement); } catch (_) { }
    try {
      this.shieldDBs.forEach(function (db) {
        try { if (db && db.isValid !== false) db.color = C(255, 255, 255, 255); } catch (_) { }
      });
    } catch (e) { err(e); }
  };

  l.dshShieldAuraBuild = function () {
    try { if (this.dshShieldAura && this.dshShieldAura.isValid) this.dshShieldAura.destroy(); } catch (_) { }
    this.dshShieldAura = null;
  };

  l.dshShieldAuraDestroy = function () {
    try { if (this.dshShieldAura && this.dshShieldAura.isValid) this.dshShieldAura.destroy(); } catch (_) { }
    this.dshShieldAura = null;
  };

  l.dshShieldFxBuild = function () {
    try {
      if (this.dshShieldFx && this.dshShieldFx.isValid) return this.dshShieldFx;
      var n = new cc.Node('DshShieldCracks');
      n.parent = this.node; n.setPosition(0, 0, 0); n.layer = LAYER;
      var g = n.addComponent(cc.Graphics);
      this.dshShieldFx = n; this.dshShieldFxG = g;
      return n;
    } catch (e) { err(e); return null; }
  };

  l.dshShieldDrawCracks = function (level) {
    this.dshShieldCrackStage = level || 0;
    try { this.dshShieldAuraBuild(); } catch (e) { err(e); }
  };

  l.dshShieldFxDestroy = function () {
    try { if (this.dshShieldFx && this.dshShieldFx.isValid) this.dshShieldFx.destroy(); } catch (_) { }
    this.dshShieldFx = null; this.dshShieldFxG = null;
  };

  l.dshShieldBurst = function () {
    try {
      var n = new cc.Node('DshShieldShatter');
      n.parent = this.node; n.setPosition(0, 110, 0); n.layer = LAYER;
      var g = n.addComponent(cc.Graphics);
      var s = style(this.dshShieldElement);
      for (var i = 0; i < 18; i++) {
        var a = i / 18 * Math.PI * 2;
        var r1 = 38 + ((i * 37) % 35);
        var r2 = r1 + 28 + ((i * 23) % 48);
        g.strokeColor = C(i % 3 === 0 ? 255 : s.fill[0], i % 3 === 0 ? 255 : s.fill[1], i % 3 === 0 ? 255 : s.fill[2], 225);
        g.lineWidth = i % 3 === 0 ? 3 : 2;
        g.moveTo(Math.cos(a) * r1, Math.sin(a) * r1);
        g.lineTo(Math.cos(a) * r2, Math.sin(a) * r2);
      }
      g.stroke();
      g.strokeColor = C(255, 255, 255, 215); g.lineWidth = 4; g.circle(0, 0, 34); g.stroke();
      g.strokeColor = C(s.tint[0], s.tint[1], s.tint[2], 210); g.lineWidth = 2; g.circle(0, 0, 48); g.stroke();
      cc.tween(n)
        .to(0.46, { scale: new cc.Vec3(1.55, 1.55, 1), position: new cc.Vec3(0, 132, 0) })
        .call(function () { try { if (n.isValid) n.destroy(); } catch (_) { } })
        .start();
    } catch (e) { err(e); }
  };

  l.dshShieldBarY = -10;
  l.dshShieldBarX = 0;
  l.dshShieldBarPulseT = 0;
  l.dshShieldFlashT = 0;

  l.dshHealFxBuild = function () {
    try {
      this.dshShieldEnsureCamera();
      var n = this.dshHealFx;
      if (!n || !n.isValid) {
        n = new cc.Node('DshShieldHealFx');
        n.parent = this.node; n.setPosition(0, 0, 0); n.layer = LAYER;
        n.addComponent(cc.Graphics);
        this.dshHealFx = n;
      }
      n.active = true; n.layer = LAYER;
      return n;
    } catch (e) { err(e); return null; }
  };

  l.dshHealFxTick = function () {
    try {
      if (!this.dshShieldActive || (this.dshShieldHP || 0) <= 0) return;
      var n = this.dshHealFx;
      if (!n || !n.isValid) n = this.dshHealFxBuild();
      if (!n) return;
      n.active = true; n.layer = LAYER;
      var g = n.getComponent('cc.Graphics'); if (!g) return;
      var now = Date.now() / 1000;
      var pulse = 0.5 + 0.5 * Math.sin(now * 2.4);
      g.clear();
      g.fillColor = C(55, 225, 105, 16 + 12 * pulse); g.ellipse(0, 4, 96, 27); g.fill();
      g.strokeColor = C(85, 255, 130, 150 + 70 * pulse); g.lineWidth = 2; g.ellipse(0, 4, 96, 27); g.stroke();
      g.strokeColor = C(95, 255, 140, 90); g.lineWidth = 1.5; g.ellipse(0, 12, 70, 20); g.stroke();
      g.fillColor = C(60, 240, 110, 20); g.ellipse(0, 120, 96, 154); g.fill();
      for (var i = 0; i < 16; i++) {
        var ph = i / 16;
        var tt = (now * 0.32 + ph) % 1;
        var y = 18 + tt * 235;
        var x = Math.sin(ph * 6.283 + now * 0.85) * 92 * (0.35 + 0.65 * tt);
        var a = Math.sin(tt * Math.PI);
        var sz = 6.5 + 4.2 * a;
        g.strokeColor = C(105, 255, 145, 65 + 185 * a); g.lineWidth = 4.2;
        g.moveTo(x - sz, y); g.lineTo(x + sz, y);
        g.moveTo(x, y - sz); g.lineTo(x, y + sz);
        g.stroke();
      }
      for (var j = 0; j < 4; j++) {
        var p2 = j / 4;
        var t2 = (now * 0.18 + p2) % 1;
        var yy = 20 + t2 * 235;
        var xx = Math.sin(p2 * 6.283 + now * 0.6) * 70;
        g.fillColor = C(70, 245, 110, 20 + 45 * Math.sin(t2 * Math.PI));
        g.circle(xx, yy, 7 + 5 * t2); g.fill();
      }
      n.dshStyleName = 'heal';
    } catch (e) { err(e); }
  };

  l.dshHealFxDestroy = function () {
    try { if (this.dshHealFx && this.dshHealFx.isValid) this.dshHealFx.destroy(); } catch (_) { }
    this.dshHealFx = null;
  };

  l.dshHealTick = function () {
    try {
      if (!this.dshShieldActive || (this.dshShieldHP || 0) <= 0) return;
      if (CONFIG.HEAL_PER_SEC <= 0) return;
      if (this.isAlive && !this.isAlive()) return;
      this.dshHealFxTick();
      var now = Date.now();
      if (!this.dshHealLastTime) this.dshHealLastTime = now;
      var elapsed = (now - this.dshHealLastTime) / 1000;
      if (elapsed >= 1) {
        var ticks = Math.floor(elapsed);
        var mx = this.toughness || (this.objdataOwn && this.objdataOwn.Toughness) || this.health;
        var before = this.health || 0;
        this.health = Math.min(mx, before + CONFIG.HEAL_PER_SEC * ticks);
        this.dshHealTotal = (this.dshHealTotal || 0) + (this.health - before);
        this.dshHealLastTime += ticks * 1000;
      }
    } catch (e) { err(e); }
  };

  l.dshShieldCameraDestroy = function () {
    try { if (this.dshShieldCamNode && this.dshShieldCamNode.isValid) this.dshShieldCamNode.destroy(); } catch (_) { }
    this.dshShieldCamNode = null;
  };

  l.dshShieldCleanup = function (full) {
    this.dshShieldBarDestroy();
    this.dshHealFxDestroy();
    this.dshShieldAuraDestroy();
    this.dshShieldFxDestroy();
    this.dshChargeBarDestroy();
    if (full) this.dshShieldCameraDestroy();
  };

  l.dshShieldReset = function (full) {
    this.dshShieldActive = false;
    this.dshShieldHP = 0;
    this.dshShieldCrackStage = 0;
    this.dshShieldFlashT = 0;
    this.dshShieldBarPulseT = 0;
    this.dshShieldLastIceAt = 0;
    this.dshHealLastTime = 0;

    if (full) {
      this.dshShieldCooldown = 0;
      this.dshShieldLastSpawnAt = 0;
      this.dshShieldEverSpawned = false;
      this.dshShieldBreaking = false;
      this.dshFirstSeenAt = Date.now();
    }

    this.dshShieldCleanup(full);
    try { if (full) this.dshShieldApplyTint(false); } catch (_) { }
  };

  l.dshShieldBreak = function () {
    if (!this.dshShieldActive) return;
    this.dshShieldActive = false;
    this.dshShieldHP = 0;
    this.dshShieldCooldown = RESPAWN_CD;
    LOG('[EVENT] shield broken, cooldown=' + RESPAWN_CD);
    try { if (SND) SND.playArray(this.shieldEndSounds, 1, .1); } catch (_) { }
    this.dshShieldBurst();
    try { origKillShield.call(this); } catch (e) { err(e); }
    this.shieldDBs.forEach(function (db) { try { if (db && db.node) db.node.active = false; } catch (_) { } });
    this.dshShieldCleanup(false);
  };

  l.dshShieldDamage = function (applied) {
    if (!this.dshShieldActive || applied <= 0) return;
    if (this.dshShieldBreaking) return;
    var cap = (this.dshShieldMax || 1) * CONFIG.DAMAGE_CAP_PCT;
    var before = this.dshShieldHP;
    if (applied > cap) applied = cap;
    if (this.dshShieldBornAt && Date.now() - this.dshShieldBornAt < CONFIG.MIN_SPAWN_GUARD_MS && this.dshShieldHP - applied <= 0) applied = Math.max(0, this.dshShieldHP - 1);
    this.dshShieldHP = (this.dshShieldHP || 0) - applied;
    if (CONFIG.LOG_ALL_OPS) LOG('[DAMAGE] ' + applied.toFixed(1) + ' hp ' + before + '->' + this.dshShieldHP);
    this.dshShieldFlashT = 0.12;
    this.dshShieldBarPulseT = 0.18;
    if (this.dshShieldHP <= 0) {
      this.dshShieldHP = 0;
      this.dshShieldBreaking = true;
      this.dshShieldBreakDelay = CONFIG.BREAK_DELAY;
      this.dshShieldBarUpdate();
      return;
    }
    var ratio = clamp01(this.dshShieldHP / (this.dshShieldMax || 1));
    var level = ratio <= 0.25 ? 3 : (ratio <= 0.5 ? 2 : (ratio <= 0.75 ? 1 : 0));
    if (level > (this.dshShieldCrackStage || 0)) {
      this.dshShieldCrackStage = level;
      this.dshShieldDrawCracks(level);
      this.dshShieldFlashT = 0.22;
    }
    this.dshShieldBarUpdate();
  };

  l.dshShieldClearByCherry = function () {
    if (!this.dshShieldActive || this.dshShieldBreaking) return;
    var before = this.dshShieldHP;
    this.dshShieldHP = 0;
    this.dshShieldFlashT = 0.3;
    this.dshShieldBarPulseT = 0.3;
    this.dshShieldBreaking = true;
    this.dshShieldBreakDelay = CONFIG.BREAK_DELAY;
    this.dshShieldBarUpdate();
    LOG('[DEBUG] cherry cleared shield hp ' + before + '->0');
  };

  l.dshIsCherryHit = function () {
    try {
      var m = window.__dshCherryExplosion;
      if (!m || Date.now() - m.t > 300) return false;
      window.__dshCherryExplosion = null;
      return true;
    } catch (_) { return false; }
  };

  l.dshShieldHit = function (dmg, type) {
    if (!this.dshShieldActive) return;
    if (CONFIG.DEBUG_CHERRY_CLEAR_SHIELD && this.dshIsCherryHit()) {
      this.dshShieldLastHit = 'cherry';
      this.dshShieldClearByCherry();
      return;
    }
    if (this.dshShieldElement === 'fire') {
      if (type !== 1) return;
      this.dshShieldLastHit = 'fire';
      this.dshShieldDamage(Math.max(CONFIG.FIRE_MIN_DAMAGE, dmg * CONFIG.FIRE_DAMAGE_MULT));
    }
  };

  l.dshShieldIceHit = function () {
    if (!this.dshShieldActive || this.dshShieldElement !== 'ice') return;
    var now = Date.now();
    if (now - (this.dshShieldLastIceAt || 0) < CONFIG.ICE_HIT_COOLDOWN_MS) return;
    this.dshShieldLastIceAt = now;
    this.dshShieldLastHit = 'ice';
    this.dshShieldDamage(CONFIG.ICE_HIT_DAMAGE);
  };

  l.dshShieldTick = function (dt) {
    if (this.health <= 0) {
      this.dshShieldActive = false;
      this.dshShieldHP = 0;
      this.dshShieldCooldown = 0;
      this.dshShieldCleanup(false);
      return;
    }
    if (!this.dshShieldActive) return;
    this.shieldCD = Infinity;
    this.shieldDBs.forEach(function (db) { try { if (db && db.node && !db.node.active) { db.node.active = true; db.playAnimation('Idle', 1 / 0); } } catch (_) { } });
    if (this.dshShieldBreaking) {
      this.dshShieldBreakDelay -= dt || 0;
      if (this.dshShieldBreakDelay <= 0) { this.dshShieldBreaking = false; this.dshShieldBreak(); return; }
    }
    if (this.dshShieldFlashT > 0) {
      this.dshShieldFlashT -= dt || 0;
      if (this.dshShieldFlashT <= 0) { this.dshShieldFlashT = 0; this.dshShieldApplyTint(false); }
      else this.dshShieldApplyTint(true);
    }
    if (this.dshShieldBarPulseT > 0) {
      this.dshShieldBarPulseT -= dt || 0;
      if (this.dshShieldBarPulseT < 0) this.dshShieldBarPulseT = 0;
    }
    if (this.dshShieldBar) this.dshShieldBarUpdate();
    this.dshHealTick();
    if (this.dshHealFx) this.dshHealFx.layer = LAYER;
    if (this.dshShieldAura) this.dshShieldAura.layer = LAYER;
    if (this.dshShieldFx) this.dshShieldFx.layer = LAYER;
  };

  l.shield = function () {
    if (CONFIG.LOG_ALL_OPS) LOG('[CALL] shield allowSpawn=' + !!this.dshShieldAllowSpawn);
    if (!this.dshShieldAllowSpawn) { LOG('[BLOCK] shield: not from spawner'); return; }
    this.dshShieldAllowSpawn = false;
    if (this.dshShieldActive) { LOG('[BLOCK] shield: already active'); return; }
    if ((this.dshShieldCooldown || 0) > 0) { LOG('[BLOCK] shield: cooldown ' + this.dshShieldCooldown.toFixed(2)); return; }
    var nowMs = Date.now();
    if (this.dshShieldLastSpawnAt && nowMs - this.dshShieldLastSpawnAt < RESPAWN_CD * 1000) {
      LOG('[BLOCK] shield: spawn interval');
      return;
    }
    try { if (SND) SND.playArray(this.shieldSounds, 1, .1); } catch (_) { }
    this.shieldCD = Infinity;
    this.dshShieldActive = true;
    this.dshShieldEverSpawned = true;
    this.dshShieldLastSpawnAt = nowMs;
    this.dshShieldCooldown = RESPAWN_CD;
    this.dshShieldCastIndex = (this.dshShieldCastIndex || 0) + 1;
    var prevEl = this.dshShieldElement;
    this.dshShieldElement = (prevEl === 'ice' ? 'fire' : (prevEl === 'fire' ? 'ice' : (Math.random() < 0.5 ? 'ice' : 'fire')));
    this.dshShieldMax = (this.dshShieldElement === 'fire') ? CONFIG.FIRE_SHIELD_HP : CONFIG.ICE_SHIELD_HP;
    this.dshShieldHP = this.dshShieldMax;
    this.dshShieldCrackStage = 0;
    this.dshShieldFlashT = 0;
    this.dshShieldBarPulseT = 0;
    this.dshShieldLastIceAt = 0;
    this.dshShieldLastHit = '';
    this.dshShieldBornAt = nowMs;
    this.dshShieldBreaking = false;
    this.dshHealLastTime = nowMs;
    this.dshHealTotal = 0;
    this.dshShieldBreakDelay = 0;
    this.shieldDBs.forEach(function (db) {
      try { db.node.active = true; db.playAnimation('Spawn', 1); } catch (_) { }
    });
    this.dshShieldApplyTint(false);
    this.dshShieldAuraBuild();
    this.dshShieldBarBuild();
    this.dshShieldBarStyleApply();
    this.dshHealFxBuild();
    this.dshShieldDrawCracks(0);
    this.dshChargeBarBuild();
    LOG('[EVENT] shield spawned element=' + this.dshShieldElement + ' max=' + this.dshShieldMax);
    try { window.__dshShieldBoss = this; } catch (_) { }
  };

  l.dealDamage = function (e) {
    try {
      if (this.dshShieldActive) {
        var dmg = (e && typeof e === 'object' && e.damage != null) ? +e.damage : (+e || 0);
        var type = (e && typeof e === 'object') ? e.damageType : undefined;
        if (dmg > 0) this.dshShieldHit(dmg, type);
        return this.health;
      }
    } catch (ex) { err(ex); }
    return origDealDamage.call(this, e);
  };

  l.setChill = function (dur, flag) {
    try { if (dur > 0) this.dshShieldIceHit(); } catch (_) { }
    return origSetChill.call(this, dur, flag);
  };

  l.setFreeze = function (dur, flag) {
    try { if (dur > 0) this.dshShieldIceHit(); } catch (_) { }
    return origSetFreeze.call(this, dur, flag);
  };

  l.killShield = function () {
    if (this.dshShieldActive && (this.dshShieldHP || 0) > 0 && !this.dshForceKill) {
      this.shieldCD = Infinity;
      this.shieldDBs.forEach(function (db) { try { if (db && db.node) { db.node.active = true; db.playAnimation('Idle', 1 / 0); } } catch (_) { } });
      if (this.dshShieldBar && this.dshShieldBar.isValid) this.dshShieldBar.active = true;
      return;
    }
    this.dshShieldActive = false;
    try { origKillShield.call(this); } catch (e) { err(e); }
    this.shieldDBs.forEach(function (db) { try { if (db && db.node) db.node.active = false; } catch (_) { } });
    this.dshShieldCleanup(false);
  };

  l.specialZombossUpdate = function (e, n, t) {
    origUpdate.call(this, e, n, t);
    dshDumpState(this, 'U');
    try { this.dshShieldTick(n || e || 0); } catch (ex) { err(ex); }
    try { this.dshChargeBarTick(n || e || 0); } catch (ex) { err(ex); }
  };

  l.specialZombossUpdateForce = function (e, n, t, i) {
    origUpdateForce.call(this, e, n, t, i);
    dshDumpState(this, 'UF');
    try { this.dshShieldTick(n || e || 0); } catch (ex) { err(ex); }
    try { this.dshChargeBarTick(n || e || 0); } catch (ex) { err(ex); }
  };

  l.specialZombossMechOnEnable = function () {
    STARTUP_LOG('[CALL] mechOnEnable');
    origEnable.call(this);
    try {
      this.dshShieldActive = false;
      this.dshShieldHP = 0;
      this.dshShieldCooldown = 0;
      this.dshShieldLastSpawnAt = 0;
      this.dshShieldEverSpawned = false;
      this.dshShieldBreaking = false;
      this.dshFirstSeenAt = Date.now();
      
      this.dshShieldCleanup(true);
    } catch (ex) { err(ex); }
  };

  l.specialZombossDieForce = function () {
    LOG('[CALL] dieForce');
    this.dshForceKill = true;
    try { origDie.call(this); } finally { this.dshForceKill = false; }
    try { this.dshShieldReset(true); } catch (ex) { err(ex); }
  };

  l.specialZombossOnDisable = function () {
    LOG('[CALL] onDisable');
    var keep = this.dshShieldActive && (this.dshShieldHP || 0) > 0;
    origDisable.call(this);
    try {
      if (keep) { this.dshShieldActive = true; this.shieldCD = Infinity; }
      else this.dshShieldReset(true);
    } catch (ex) { err(ex); }
  };

  l.__dshShieldOrig = {
    shield: origShield, killShield: origKillShield, dealDamage: origDealDamage,
    update: origUpdate, updateForce: origUpdateForce, enable: origEnable,
    die: origDie, disable: origDisable, setChill: origSetChill, setFreeze: origSetFreeze
  };
  l.__dshShieldPatched = true;

  l.dshShieldSpawner = function (dt) {
    try {
      if (!this.dshFirstSeenAt) this.dshFirstSeenAt = Date.now();
      if (Date.now() - this.dshFirstSeenAt < CONFIG.FIRST_SHIELD_DELAY_MS) return;
      if (this.health <= 0) return;

      if (this.dshShieldActive || this.dshShieldBreaking) return;
      if (this.dshShieldEverSpawned !== true) {
        this.dshShieldAllowSpawn = true;
        try { this.shield(); } finally { this.dshShieldAllowSpawn = false; }
        return;
      }
      var cd = this.dshShieldCooldown || 0;
      if (cd > 0) {
        this.dshShieldCooldown = Math.max(0, cd - (dt || 0));
        return;
      }
      this.dshShieldAllowSpawn = true;
      try { this.shield(); } finally { this.dshShieldAllowSpawn = false; }
    } catch (e) { LOGERR('spawner', e); }
  };
}

function findBosses() {
  const out = [];
  if (!CC || !CC.director) return out;
  const scene = CC.director.getScene();
  if (!scene) return out;
  const walk = (n, d) => {
    if (!n || d > 80) return;
    for (const c of (n.components || [])) {
      try {
        if (c && c.currentMechStages && c.shieldDBs && typeof c.shield === 'function') out.push(c);
      } catch (e) { }
    }
    for (const ch of (n.children || [])) walk(ch, d + 1);
  };
  walk(scene, 0);
  return out;
}

function tryPatch() {
  if (patched && proto) return true;
  let p = null;
  try {
    const C = CC.js && CC.js.getClassByName && CC.js.getClassByName('KongfuBossChiZombie');
    if (C && C.prototype && typeof C.prototype.shield === 'function') p = C.prototype;
  } catch (e) { }
  if (!p) {
    const bosses = findBosses();
    if (bosses.length) p = Object.getPrototypeOf(bosses[0]);
  }
  if (!p) return false;
  install(p, CC);
  wrapBossMethods(p);
  proto = p;
  patched = true;
  STARTUP_LOG('[SETUP] patched KongfuBossChiZombie prototype');
  return true;
}

function adopt(b) {
  if (!b) return;
  if (!b.dshFirstSeenAt) b.dshFirstSeenAt = Date.now();
  if (Date.now() - b.dshFirstSeenAt < CONFIG.FIRST_SHIELD_DELAY_MS) return;
  if (b.health <= 0) return;

  if (b.dshShieldActive) return;
  if ((b.dshShieldCooldown || 0) > 0) {
    try {
      b.shieldCD = Infinity;
      (b.shieldDBs || []).forEach(function (db) { try { if (db && db.node) db.node.active = false; } catch (_) { } });
      LOG('[BLOCK] adopt: cooldown ' + b.dshShieldCooldown.toFixed(2));
    } catch (e) { LOGERR('adopt-close', e); }
    return;
  }
  var nowMs = Date.now();
  if (b.dshShieldLastSpawnAt && nowMs - b.dshShieldLastSpawnAt < CONFIG.RESPAWN_CD * 1000) {
    try {
      b.shieldCD = Infinity;
      (b.shieldDBs || []).forEach(function (db) { try { if (db && db.node) db.node.active = false; } catch (_) { } });
      LOG('[BLOCK] adopt: spawn interval');
    } catch (e) { LOGERR('adopt-close2', e); }
    return;
  }
  try {
    b.dshShieldActive = true;
    b.dshShieldEverSpawned = true;
    b.dshShieldLastSpawnAt = nowMs;
    b.dshShieldCooldown = CONFIG.RESPAWN_CD;
    b.dshShieldElement = (Math.random() < 0.5 ? 'ice' : 'fire');
    b.dshShieldMax = (b.dshShieldElement === 'fire') ? CONFIG.FIRE_SHIELD_HP : CONFIG.ICE_SHIELD_HP;
    b.dshShieldHP = b.dshShieldMax;
    b.dshShieldCrackStage = 0;
    b.dshShieldFlashT = 0;
    b.dshShieldBarPulseT = 0;
    b.dshShieldLastIceAt = 0;
    b.dshShieldLastHit = '';
    b.dshShieldBornAt = nowMs;
    b.dshShieldBreaking = false;
    b.dshShieldBreakDelay = 0;
    b.dshHealLastTime = nowMs;
    b.dshHealTotal = 0;
    b.shieldCD = Infinity;
    b.dshShieldBarBuild();
    b.dshHealFxBuild && b.dshHealFxBuild();
    b.dshShieldApplyTint && b.dshShieldApplyTint(false);
    b.dshChargeBarBuild && b.dshChargeBarBuild();
    LOG('[EVENT] adopted element=' + b.dshShieldElement);
  } catch (e) { LOGERR('adopt', e); }
}

function tick() {
  try {
    patchCherryBomb(false);

    const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    let dt = 1 / 60;
    if (__lastTick) dt = Math.min(0.1, Math.max(0.001, (now - __lastTick) / 1000));
    __lastTick = now;

    if (!tryPatch()) return;
    const bosses = findBosses();
    for (const b of bosses) {
      if (!b.dshFirstSeenAt) b.dshFirstSeenAt = Date.now();
      if (b.health <= 0) continue;

      if (b.dshShieldActive) {
        try { b.dshShieldTick && b.dshShieldTick(dt); } catch (e) { LOGERR('tick-boss', e); }
        try { b.dshChargeBarTick && b.dshChargeBarTick(dt); } catch (e) { LOGERR('charge-boss', e); }
      } else {
        try { b.dshShieldSpawner && b.dshShieldSpawner(dt); } catch (e) { LOGERR('spawner-call', e); }
        try { b.dshChargeBarTick && b.dshChargeBarTick(dt); } catch (e) { LOGERR('charge-boss', e); }
        if (!b.dshShieldActive && hasActiveOriginalShieldNode(b)) {
          LOG('[DETECT] original node active, adopt');
          adopt(b);
        }
      }
    }
  } catch (e) { LOGERR('ticker', e); }
}

export async function setup() {
  STARTUP_LOG('[SETUP] entered');
  try {
    CC = await System.import('cc');
  } catch (e) {
    LOGERR('import-cc', e);
    return;
  }
  try {
    const snd = await System.import('chunks:///_virtual/SoundRescourses.ts');
    SND = snd.sounds || (snd.default && snd.default.sounds) || null;
  } catch (e) { LOGERR('import-sounds', e); }
  STARTUP_LOG('[SETUP] sounds=' + !!SND);
  tryPatch();
  patchCherryBomb(true);
  ticker = tick;
  CC.director.on(CC.Director.EVENT_AFTER_UPDATE, ticker);
  STARTUP_LOG('[SETUP] done patched=' + patched + ' cherryDebug=' + CONFIG.DEBUG_CHERRY_CLEAR_SHIELD);
}

export function cleanup() {
  try {
    if (CC && ticker) CC.director.off(CC.Director.EVENT_AFTER_UPDATE, ticker);
  } catch (e) { }
  try {
    for (const b of findBosses()) {
      try { if (b.dshShieldCleanup) b.dshShieldCleanup(true); } catch (e) { }
      b.dshShieldActive = false;
    }
  } catch (e) { }
  try {
    if (proto && proto.__dshShieldOrig) {
      const o = proto.__dshShieldOrig;
      proto.shield = o.shield;
      proto.killShield = o.killShield;
      proto.dealDamage = o.dealDamage;
      proto.specialZombossUpdate = o.update;
      proto.specialZombossUpdateForce = o.updateForce;
      proto.specialZombossMechOnEnable = o.enable;
      proto.specialZombossDieForce = o.die;
      proto.specialZombossOnDisable = o.disable;
      proto.setChill = o.setChill;
      proto.setFreeze = o.setFreeze;
      proto.__dshShieldPatched = false;
      proto.__dshShieldOrig = null;
    }
  } catch (e) { LOGERR('cleanup-restore', e); }
  try { if (window) delete window.__dshShieldBoss; } catch (e) { }
  STARTUP_LOG('[CLEANUP] done');
}